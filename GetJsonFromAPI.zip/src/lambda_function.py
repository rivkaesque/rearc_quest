import boto3
import urllib.request
import json

def lambda_handler(event, context):
    #get configurations
    source_url = "https://honolulu-api.datausa.io/tesseract/data.jsonrecords?cube=acs_yg_total_population_1&drilldowns=Year%2CNation&locale=en&measures=Population"
    bucket_name = event.get('bucket_name', 'rivkasfirstawsbucket')
    target_folder = event.get('target_folder', 'population_data/raw/')
    target_filename = event.get('target_file_name', 'population_data.json')

    try:
        # Fetch JSON data
        with urllib.request.urlopen(source_url) as response:
            data_json = json.loads(response.read())

        # Upload JSON to S3
        boto3.client("s3").put_object(
            Bucket=bucket_name,
            Key= target_folder + target_filename,
            Body=json.dumps(data_json, indent=2),
            ContentType="application/json"
        )

        return  f"results visible at s3://{bucket_name}/{target_folder}{target_filename} "

    except Exception as e:
        raise Exception(f"Error: {str(e)}")
        #Todo - better error handling